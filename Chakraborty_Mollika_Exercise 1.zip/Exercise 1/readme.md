# CART 263 Creative Computation 2, Winter 2023 

## Exercise 1: Ping Pong Ball Game Development using p5.js 

## Overview 

* This exercise has been an exceptional learning curve and was give to jog our memories after the festive breaks, the objective was to recreate or improvize a well known game called ping pong ball/tic tac toe. 

## Description of the Exercise 

* There were several set of rules to be met in the exercise, the ball needed to bounce between the two sliders at each end of the playing canvas or court. The rectangles or the sliders in each end represent the players. Every time the opposite side player misses the ball the other player scores and the ball gets back to the origin which is the centre of the court. The player that scores 10 first is declared to be the winner of the game. 

## References used 

* https://p5js.org/, this website has been used for the complex changes in the code that are pre existing. 
