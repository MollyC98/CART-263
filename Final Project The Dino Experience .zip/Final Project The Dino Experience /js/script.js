/**
Final Project, The Dino Experience 
Negar and Mollika 

This is a template. You must fill in the title,
author, and this description to match your project!
*/
let speech;

function setup() {
  noCanvas();
  // Create a Speech Recognition object with callback
  speech = new p5.SpeechRec('en-US', gotSpeech);
  // "Continuous recognition" (as opposed to one time only)
  let continuous = true;
  // If you want to try partial recognition (faster, less accurate)
  let interimResults = false;
  // This must come after setting the properties
  speech.start(continuous, interimResults);

  // DOM element to display results
  let output = select('#speech');

  // Speech recognized event
  function gotSpeech() {
    // Something is there
    // Get it as a string, you can also get JSON with more info
    console.log(speech);
    if (speechRec.resultValue) {
      let said = speechRec.resultString;
      // Show user
      output.html(said);
    }
  }
}




function draw() {
   background(0);
   translate(width/2, height/2);
   
   // draw the Sun
   fill(255, 255, 0);
   ellipse(0, 0, 100, 100);
   
   // draw Mercury
   rotate(frameCount / 50);
   translate(100, 0);
   fill(200);
   ellipse(0, 0, 10, 10);
   
   // draw Venus
   rotate(frameCount / 75);
   translate(50, 0);
   fill(255, 200, 0);
   ellipse(0, 0, 20, 20);
   
   // draw Earth
   rotate(frameCount / 100);
   translate(80, 0);
   fill(0, 150, 255);
   ellipse(0, 0, 25, 25);
}