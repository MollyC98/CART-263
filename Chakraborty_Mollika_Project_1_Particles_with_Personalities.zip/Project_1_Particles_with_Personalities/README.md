# CART 263 PROJECT 1; PARTICLES WITH PERSONALITIES 

## TOPIC; IN A PARTY, LOVING IT 

## Overview 

* The project; particles with personalities describe the creation of a particle system with varied interesting shapes,forms, colours,etc. that defines the characteristics of the particles as per the individual topics given to us. I was given the topic; In a party, loving it! 

* The project helps us with descriptive understanding of class or objects coding. I personally have utilised the FFT from p5.js Sound library and linked it with my particles to have different variations in terms of colours, speed and number of particles analysing the frequency of the selected music within the code. 

## Description of the process 


